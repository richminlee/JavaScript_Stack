import React, {useEffect, useState } from 'react';
import { Link, navigate } from '@reach/router';
import axios from 'axios';
import moment from 'moment';
import DeleteButton from './DeleteButton';
export default props => {
    const [belts, setBelts] = useState([]);
    const [sorted, setSorted] = useState([]);
    useEffect(() => {
        console.log("hello");
        axios.get('http://localhost:8000/api/belt')
        .then(res => setBelts(res.data))

    }, [])
    useEffect(() => {
        setSorted(belts.sort((a,b) => a.dueDate < b.dueDate))
        console.log(sorted)
    })
    const removeFromDom = beltId => {
        setBelts(belts.filter(belt => belt._id !== beltId))
    }
    const statusHandler = (status, id, idx) => {
        axios.put('http://localhost:8000/api/belt/' + id, status)
        .then(res => {
            const beltCopy = [...belts];
            const selectedBelt = beltCopy[idx];
            selectedBelt.status = "1" ;
            setBelts(beltCopy);
        })
    }
    const statusHandler1 = (status, id, idx) => {
        axios.put('http://localhost:8000/api/belt/' + id, status)
        .then(res => {
            const beltCopy = [...belts];
            const selectedBelt = beltCopy[idx];
            selectedBelt.status = "2" ;
            setBelts(beltCopy);
        })
    }
    return(
        <div className="container border border-dark">
                            <div className="row">
                                <div className="col border border-dark h3">Backlog</div>
                                <div className="col border border-dark h3">In Progress</div>
                                <div className="col border border-dark h3">Completed</div>
                            </div>
                            
            {sorted.map((belt, idx)=>{ 
                return(
                    <div key={idx} className="row">
                        <div className="col border border-dark">
                            <div className="row">
                                <div className="col ">
                                    {
                                        belt.status === "0"?
                                        <div>
                                        <div className="row h5">{belt.project}</div>
                                        <div className="row">
                                            {
                                            moment(belt.dueDate).format('YYYY-MM-DD') >= moment(new Date ()).format('YYYY-MM-DD')?
                                            <div> {moment(belt.dueDate).format('MM-DD-YYYY')} </div>
                                            :
                                            <div style={{color:"red"}}> {moment(belt.dueDate).format('MM-DD-YYYY')} </div>
                                            }
                                            </div>
                                        <button onClick={(e)=> {statusHandler(belt.status, belt._id, idx)}}>Start Project</button>
                                        </div>
                                        :
                                        ""
                                    }
                                </div>
                            </div>
                        </div>
                        <div className="col border border-dark">
                            <div className="row">
                                <div className="col ">
                                    {
                                        belt.status === "1"?
                                        <div>
                                        <div className="row h5">{belt.project}</div>
                                        <div className="row">{moment(belt.dueDate).format('MM-DD-YYYY')}</div>
                                        <button onClick={(e)=> {statusHandler1(belt.status, belt._id, idx)}}>Move to Completed</button>
                                        </div>
                                        :
                                        ""
                                    }
                                </div>
                            </div>
                        </div>
                        <div className="col border border-dark">
                            <div className="row">
                                <div className="col ">
                                    {
                                        belt.status === "2"?
                                        <div>
                                        <div className="row h5">{belt.project}</div>
                                        <div className="row">{moment(belt.dueDate).format('MM-DD-YYYY')}</div>
                                        <DeleteButton beltId={belt._id} successCallback={() => removeFromDom(belt._id)}/>
                                        </div>
                                        :
                                        ""
                                    }
                                </div>
                            </div>
                        </div>
                    </div> 
            )
})}
        </div>

    )
}